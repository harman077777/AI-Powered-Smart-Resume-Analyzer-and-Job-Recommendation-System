from openai import OpenAI
import json

# Replace with your OpenAI API key
client = OpenAI(api_key="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")


def is_resume(text: str):
    """
    Check if the text is a professional resume using AI.
    Returns:
        is_valid (bool), score (0-5)
    """
    text = text.replace("\n", " ").strip()
    prompt = f"""
You are an AI that determines if a text is a professional resume.
Text: '''{text}'''
Answer ONLY in JSON:
{{ "is_resume": true/false, "score": 0-5 }}
"""

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0
        )

        content = response.choices[0].message.content
        result = json.loads(content)

        return result.get("is_resume", False), result.get("score", 0)
    except Exception as e:
        print("Error in is_resume:", e)
        return False, 0


def extract_resume_info(text: str):
    """
    Extract info from resume text using AI:
    Name, Email, Phone, Age, Skills, Experience Level, Objective/Summary
    """
    text = text.replace("\n", " ").strip()
    prompt = f"""
You are an AI resume parser. Extract from this resume text:

Name, Email, Phone, Age, Skills (list), Experience Level (Fresher/Mid/Senior), Objective/Summary.

Text: '''{text}'''

Respond ONLY in JSON like:
{{ "name": "", "email": "", "phone": "", "age": "", "skills": [], "experience": "", "objective": "" }}
"""

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0
        )

        content = response.choices[0].message.content
        result = json.loads(content)
        # normalize keys to lowercase
        normalized = {k.lower(): v for k, v in result.items()}
        return normalized

    except Exception as e:
        print("Error in extract_resume_info:", e)
        return {
            "name": "Not found",
            "email": "Not found",
            "phone": "Not found",
            "age": "Not specified",
            "skills": [],
            "experience": "Not specified",
            "objective": "Not specified"
        }
