# app.py
from flask import Flask, render_template, request
from extractor_utils import extract_text  # your PDF/TXT/DOCX text extractor
from resume_logic import is_resume, extract_resume_info
import os

app = Flask(__name__)

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

ALLOWED_EXTENSIONS = {"pdf", "txt", "docx"}


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route("/", methods=["GET", "POST"])
def index():
    result = None

    if request.method == "POST":
        file = request.files.get("resume")

        if not file or file.filename == "":
            result = {"error": "No file selected"}
        elif not allowed_file(file.filename):
            result = {"error": "Invalid file type"}
        else:
            file_path = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(file_path)

            text = extract_text(file_path)

            # 1️⃣ Check if AI thinks it's a resume
            is_valid, score = is_resume(text)

            if not is_valid:
                result = {
                    "is_resume": False,
                    "score": score
                }
            else:
                # 2️⃣ Extract detailed info
                info = extract_resume_info(text)
                result = {
                    "is_resume": True,
                    "score": score,
                    **info
                }

    return render_template("index.html", result=result)


if __name__ == "__main__":
    app.run(debug=True)
