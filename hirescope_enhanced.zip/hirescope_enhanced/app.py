from flask import Flask, render_template, request, send_file, redirect, url_for
import os
import re
import PyPDF2
import docx2txt
import logging
import requests
from datetime import datetime
from werkzeug.utils import secure_filename
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, HRFlowable, Table, TableStyle

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = "uploads"
app.config["GENERATED_FOLDER"] = "generated"
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5MB limit
app.config["ALLOWED_EXTENSIONS"] = {'pdf', 'docx', 'doc', 'txt'}
app.secret_key = os.environ.get('SECRET_KEY', os.urandom(32))  # More secure

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.FileHandler('hirescope.log'), logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

# Ensure folders exist
for folder in [app.config["UPLOAD_FOLDER"], app.config["GENERATED_FOLDER"]]:
    if not os.path.exists(folder):
        os.makedirs(folder)

# --- SKILL DATABASE FOR RADAR (Enhanced with 60+ skills) ---
SKILL_DB = {
    "Backend": ["python", "py", "java", "jdk", "sql", "mysql", "postgresql", "sqlite", "flask", "django", 
                "node", "nodejs", "node.js", "postgres", "mongo", "mongodb", "php", "c++", "cpp", "redis", 
                "express", "express.js", "spring", "spring boot", "graphql", "rest api", "restful"],
    "Frontend": ["html", "html5", "css", "css3", "javascript", "js", "es6", "react", "reactjs", "react.js",
                 "vue", "vuejs", "vue.js", "angular", "angularjs", "tailwind", "tailwindcss", "bootstrap", 
                 "typescript", "ts", "sass", "scss", "webpack", "redux", "nextjs", "next.js"],
    "Data": ["pandas", "numpy", "scikit", "scikit-learn", "sklearn", "tensorflow", "tf", "pytorch", 
             "tableau", "powerbi", "power bi", "excel", "jupyter", "matplotlib", "seaborn", "r",
             "spark", "apache spark", "pyspark", "hadoop"],
    "DevOps": ["aws", "amazon web services", "docker", "kubernetes", "k8s", "jenkins", "git", "github", 
               "gitlab", "linux", "ubuntu", "centos", "azure", "microsoft azure", "gcp", "google cloud", 
               "terraform", "ansible", "ci/cd", "cicd", "nginx"]
}

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def validate_file_content(filepath):
    """Validate that file content matches its extension"""
    ext = filepath.rsplit('.', 1)[1].lower()
    try:
        if ext == 'pdf':
            with open(filepath, 'rb') as f:
                header = f.read(5)
                return header.startswith(b'%PDF')
        elif ext in ['docx', 'doc']:
            with open(filepath, 'rb') as f:
                header = f.read(4)
                return header == b'PK\x03\x04'
        return True
    except Exception as e:
        logger.error(f"File validation error: {str(e)}")
        return False

def extract_text(filepath):
    """Extract text from PDF, DOCX, or TXT files"""
    ext = filepath.rsplit('.', 1)[1].lower()
    text = ""
    try:
        if ext == 'pdf':
            with open(filepath, "rb") as f:
                reader = PyPDF2.PdfReader(f)
                for page in reader.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
        elif ext in ['docx', 'doc']:
            text = docx2txt.process(filepath)
        elif ext == 'txt':
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                text = f.read()
    except Exception as e:
        logger.error(f"Text extraction error: {str(e)}")
        return ""
    return text

def analyze_resume(text):
    """Enhanced resume analysis with better skill detection and scoring"""
    text_lower = text.lower()
    stats = {k: 0 for k in SKILL_DB.keys()}
    found_skills = []

    # 1. Enhanced Radar Chart Calculation
    for category, skills in SKILL_DB.items():
        category_skills = set()
        for skill in skills:
            if skill in text_lower:
                category_skills.add(skill.split()[0])  # Get base skill name
        
        # Score based on unique skills found
        unique_count = len(category_skills)
        stats[category] = min(unique_count * 15, 100)  # Cap at 100
        found_skills.extend(list(category_skills))

    # 2. Enhanced Scoring (More strict and comprehensive)
    score = 20  # Lower base
    strengths, weaknesses, suggestions = [], [], []

    # Skill Density (25 points)
    skill_count = len(set(found_skills))
    if skill_count >= 15:
        score += 25
        strengths.append(f"Excellent skill coverage ({skill_count} technical skills detected)")
    elif skill_count >= 10:
        score += 20
        strengths.append(f"Good skill diversity ({skill_count} skills)")
    elif skill_count >= 5:
        score += 12
        weaknesses.append(f"Moderate skill coverage ({skill_count} skills)")
    else:
        score += 5
        weaknesses.append(f"Low Skill Density: Only {skill_count} skills found")
        suggestions.append("Add 10-15 relevant technical skills for your target role")

    # Metric Check (25 points) - More sophisticated
    metrics = re.findall(r'\d+%|\$\d+[\d,]*|[0-9]{1,3}[,]?[0-9]*\+?(?:\s*(?:users|customers|sales|revenue|performance|efficiency|growth|increase|decrease))', text_lower)
    metric_count = len(metrics)
    if metric_count >= 8:
        score += 25
        strengths.append(f"Strong quantified achievements ({metric_count} metrics)")
    elif metric_count >= 4:
        score += 15
        strengths.append(f"Decent use of metrics ({metric_count} found)")
    else:
        score += 5
        weaknesses.append(f"Weak Impact: Only {metric_count} metrics found")
        suggestions.append("Quantify your bullets: 'Improved efficiency by 20%' instead of 'Improved efficiency'")

    # Format Quality (15 points)
    section_keywords = ['experience', 'education', 'skills', 'projects', 'summary']
    sections_found = sum(1 for keyword in section_keywords if keyword in text_lower)
    if sections_found >= 4:
        score += 15
        strengths.append("Well-structured with all key sections")
    elif sections_found >= 3:
        score += 10
    else:
        score += 5
        weaknesses.append("Missing important sections")
        suggestions.append("Include: Summary, Experience, Education, Skills, Projects")

    # Action Verbs (15 points)
    action_verbs = ['developed', 'implemented', 'designed', 'led', 'managed', 'created', 
                    'improved', 'optimized', 'achieved', 'delivered', 'collaborated']
    action_count = sum(1 for verb in action_verbs if verb in text_lower)
    if action_count >= 8:
        score += 15
        strengths.append("Strong use of action verbs")
    elif action_count >= 5:
        score += 10
    else:
        score += 5
        weaknesses.append("Weak action verbs usage")
        suggestions.append("Start bullet points with strong action verbs")

    # Professional Links (10 points)
    link_score = 0
    if "linkedin.com" in text_lower:
        link_score += 5
        strengths.append("LinkedIn profile included")
    else:
        suggestions.append("Add LinkedIn URL for social proof")
    
    if "github.com" in text_lower:
        link_score += 3
        strengths.append("GitHub profile included")
    
    if any(word in text_lower for word in ['portfolio', 'website', 'personal site']):
        link_score += 2
    
    score += min(link_score, 10)

    # Resume Length (10 points)
    word_count = len(text.split())
    if 400 <= word_count <= 800:
        score += 10
        strengths.append("Optimal resume length")
    elif 300 <= word_count < 400 or 800 < word_count <= 1000:
        score += 7
    else:
        weaknesses.append("Resume length not optimal (aim for 400-800 words)")
        score += 3

    # Final suggestions
    if score < 60:
        suggestions.insert(0, "🚨 Priority: Use the Builder to restructure your resume entirely")

    return round(min(score, 100)), list(set(found_skills)), strengths, weaknesses, suggestions, stats

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/analyze", methods=["GET", "POST"])
def analyze():
    if request.method == "POST":
        # Enhanced validation
        if 'resume' not in request.files:
            logger.warning("No file in request")
            return "No file uploaded", 400
        
        file = request.files.get("resume")
        if not file or file.filename == '':
            logger.warning("Empty file uploaded")
            return "No file selected", 400
        
        # Validate file type
        if not allowed_file(file.filename):
            logger.warning(f"Invalid file type: {file.filename}")
            return f"Invalid file type. Allowed: {', '.join(app.config['ALLOWED_EXTENSIONS'])}", 400
        
        # Secure filename with timestamp
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{timestamp}_{filename}"
        path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        
        try:
            file.save(path)
            logger.info(f"File saved: {filename}")
            
            # Validate file content
            if not validate_file_content(path):
                os.remove(path)
                logger.error(f"Invalid file content: {filename}")
                return "Invalid file content. File may be corrupted.", 400
            
            # Extract and analyze
            text = extract_text(path)
            if not text or len(text.strip()) < 50:
                os.remove(path)
                logger.error("Extracted text too short")
                return "Could not extract text from file or file is too short", 400
            
            score, skills, strengths, weaknesses, suggestions, stats = analyze_resume(text)
            logger.info(f"Analysis complete: Score={score}, Skills={len(skills)}")
            
            # Clean up uploaded file
            try:
                os.remove(path)
                logger.info(f"Cleaned up file: {filename}")
            except Exception as e:
                logger.error(f"Failed to delete file: {str(e)}")
            
            return render_template("result.html", score=score, skills=skills, 
                                   strengths=strengths, weaknesses=weaknesses, 
                                   suggestions=suggestions, stats=stats)
        
        except Exception as e:
            logger.error(f"Analysis error: {str(e)}")
            if os.path.exists(path):
                os.remove(path)
            return f"Error analyzing resume: {str(e)}", 500
    
    return render_template("upload.html")

@app.route("/builder")
def builder():
    return render_template("builder.html")

@app.route("/generate", methods=["POST"])
def generate():
    """Generate a professional, ATS-optimized resume PDF"""
    data = request.form
    
    # Validate required fields
    if not data.get('name') or not data.get('email'):
        logger.error("Missing required fields")
        return "Missing required fields: name and email", 400
    
    try:
        # Generate secure filename with timestamp
        name_safe = secure_filename(data.get('name'))
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{name_safe}_{timestamp}_Resume.pdf"
        path = os.path.join(app.config["GENERATED_FOLDER"], filename)
        
        doc = SimpleDocTemplate(
            path, 
            pagesize=A4,
            rightMargin=50,
            leftMargin=50,
            topMargin=40,
            bottomMargin=40
        )
        
        styles = getSampleStyleSheet()
        elements = []
        
        # ===== CUSTOM PROFESSIONAL STYLES =====
        
        # Name style - Large and bold
        name_style = ParagraphStyle(
            'CustomName',
            parent=styles['Heading1'],
            fontSize=28,
            textColor=colors.HexColor("#1a202c"),
            spaceAfter=8,
            fontName="Helvetica-Bold",
            alignment=1,  # Center
            leading=32
        )
        
        # Contact style - Clean and professional
        contact_style = ParagraphStyle(
            'CustomContact',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor("#4a5568"),
            spaceAfter=20,
            alignment=1,  # Center
            leading=14
        )
        
        # Section header style - Bold with accent color
        section_header_style = ParagraphStyle(
            'CustomHeader',
            parent=styles['Heading2'],
            fontSize=13,
            textColor=colors.HexColor("#2563eb"),
            spaceBefore=18,
            spaceAfter=10,
            fontName="Helvetica-Bold",
            borderWidth=0,
            borderPadding=0,
            leftIndent=0,
            leading=16
        )
        
        # Subsection style (Job title, Project name)
        subsection_style = ParagraphStyle(
            'CustomSubsection',
            parent=styles['Normal'],
            fontSize=11,
            textColor=colors.HexColor("#1a202c"),
            fontName="Helvetica-Bold",
            spaceBefore=8,
            spaceAfter=4,
            leading=14
        )
        
        # Body text style - Clean and readable
        body_style = ParagraphStyle(
            'CustomBody',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor("#2d3748"),
            spaceBefore=2,
            spaceAfter=2,
            leftIndent=15,
            leading=14
        )
        
        # ===== HEADER SECTION =====
        
        # Name
        elements.append(Paragraph(data.get('name', '').upper(), name_style))
        
        # Contact information - Build contact line
        contact_parts = []
        if data.get('email'):
            contact_parts.append(data.get('email'))
        if data.get('phone'):
            contact_parts.append(data.get('phone'))
        if data.get('linkedin'):
            linkedin_clean = data.get('linkedin').replace('https://', '').replace('http://', '')
            contact_parts.append(linkedin_clean)
        if data.get('github'):
            github_clean = data.get('github').replace('https://', '').replace('http://', '')
            contact_parts.append(github_clean)
        if data.get('portfolio'):
            portfolio_clean = data.get('portfolio').replace('https://', '').replace('http://', '')
            contact_parts.append(portfolio_clean)
        
        contact_line = ' • '.join(contact_parts)
        elements.append(Paragraph(contact_line, contact_style))
        
        # Horizontal line separator
        elements.append(HRFlowable(
            width="100%",
            thickness=1.5,
            color=colors.HexColor("#e2e8f0"),
            spaceAfter=12
        ))
        
        # ===== PROFESSIONAL SUMMARY =====
        if data.get('summary') and len(data.get('summary').strip()) > 10:
            elements.append(Paragraph("PROFESSIONAL SUMMARY", section_header_style))
            
            # Split summary into lines and format as bullets
            summary_lines = [line.strip() for line in data.get('summary').split('\n') if line.strip()]
            for line in summary_lines:
                # Remove existing bullet if present
                line = line.lstrip('•').lstrip('-').lstrip('*').strip()
                if line:
                    elements.append(Paragraph(f"• {line}", body_style))
            elements.append(Spacer(1, 8))
        
        # ===== EDUCATION =====
        if data.get('edu_level') or data.get('edu_field'):
            elements.append(Paragraph("EDUCATION", section_header_style))
            
            edu_parts = []
            if data.get('edu_level') and data.get('edu_field'):
                edu_parts.append(f"{data.get('edu_level')} in {data.get('edu_field')}")
            elif data.get('edu_level'):
                edu_parts.append(data.get('edu_level'))
            elif data.get('edu_field'):
                edu_parts.append(data.get('edu_field'))
            
            if data.get('edu_institution'):
                edu_parts.append(f" | {data.get('edu_institution')}")
            
            if data.get('edu_year'):
                edu_parts.append(f" | {data.get('edu_year')}")
            
            edu_line = ''.join(edu_parts)
            elements.append(Paragraph(edu_line, subsection_style))
            
            if data.get('edu_gpa'):
                elements.append(Paragraph(f"GPA: {data.get('edu_gpa')}", body_style))
            
            elements.append(Spacer(1, 8))
        
        # ===== WORK EXPERIENCE =====
        if data.get('experience') and len(data.get('experience').strip()) > 10:
            elements.append(Paragraph("PROFESSIONAL EXPERIENCE", section_header_style))
            
            # Parse experience section
            exp_text = data.get('experience')
            exp_lines = [line.strip() for line in exp_text.split('\n') if line.strip()]
            
            for line in exp_lines:
                line = line.strip()
                if not line:
                    continue
                
                # Check if line is a job title/company (contains | or looks like header)
                if '|' in line and not line.startswith('•') and not line.startswith('-'):
                    elements.append(Paragraph(line, subsection_style))
                else:
                    # It's a bullet point
                    line = line.lstrip('•').lstrip('-').lstrip('*').strip()
                    if line:
                        elements.append(Paragraph(f"• {line}", body_style))
            
            elements.append(Spacer(1, 8))
        
        # ===== TECHNICAL SKILLS =====
        if data.get('skills') and len(data.get('skills').strip()) > 5:
            elements.append(Paragraph("TECHNICAL SKILLS", section_header_style))
            
            skills_text = data.get('skills')
            skill_lines = [line.strip() for line in skills_text.split('\n') if line.strip()]
            
            for line in skill_lines:
                line = line.strip()
                if line:
                    # Check if line has category (contains :)
                    if ':' in line:
                        elements.append(Paragraph(f"• {line}", body_style))
                    else:
                        # Just a list of skills
                        elements.append(Paragraph(f"• {line}", body_style))
            
            elements.append(Spacer(1, 8))
        
        # ===== PROJECTS =====
        if data.get('projects') and len(data.get('projects').strip()) > 10:
            elements.append(Paragraph("PROJECTS", section_header_style))
            
            project_text = data.get('projects')
            project_lines = [line.strip() for line in project_text.split('\n') if line.strip()]
            
            for line in project_lines:
                line = line.strip()
                if not line:
                    continue
                
                # Check if it's a project title (contains | or no bullet)
                if '|' in line and not line.startswith('•') and not line.startswith('-'):
                    elements.append(Paragraph(line, subsection_style))
                else:
                    line = line.lstrip('•').lstrip('-').lstrip('*').strip()
                    if line:
                        elements.append(Paragraph(f"• {line}", body_style))
            
            elements.append(Spacer(1, 8))
        
        # ===== CERTIFICATIONS =====
        if data.get('certifications') and len(data.get('certifications').strip()) > 5:
            elements.append(Paragraph("CERTIFICATIONS", section_header_style))
            
            cert_lines = [line.strip() for line in data.get('certifications').split('\n') if line.strip()]
            for line in cert_lines:
                line = line.lstrip('•').lstrip('-').lstrip('*').strip()
                if line:
                    elements.append(Paragraph(f"• {line}", body_style))
            
            elements.append(Spacer(1, 8))
        
        # ===== AWARDS & ACHIEVEMENTS =====
        if data.get('awards') and len(data.get('awards').strip()) > 5:
            elements.append(Paragraph("AWARDS & ACHIEVEMENTS", section_header_style))
            
            award_lines = [line.strip() for line in data.get('awards').split('\n') if line.strip()]
            for line in award_lines:
                line = line.lstrip('•').lstrip('-').lstrip('*').strip()
                if line:
                    elements.append(Paragraph(f"• {line}", body_style))
            
            elements.append(Spacer(1, 8))
        
        # ===== LANGUAGES =====
        if data.get('languages') and len(data.get('languages').strip()) > 3:
            elements.append(Paragraph("LANGUAGES", section_header_style))
            elements.append(Paragraph(f"• {data.get('languages')}", body_style))
            elements.append(Spacer(1, 8))
        
        # Build the PDF
        doc.build(elements)
        logger.info(f"Professional resume generated: {filename}")
        
        return send_file(path, as_attachment=True, download_name=filename)
    
    except Exception as e:
        logger.error(f"PDF generation error: {str(e)}")
        return f"Error generating resume: {str(e)}", 500


@app.route("/find-jobs", methods=["POST"])
def find_jobs():
    """Find job recommendations based on user's skills using web search"""
    try:
        # Get skills from form
        skills_str = request.form.get('skills', '')
        if not skills_str:
            return render_template('jobs.html', error="No skills provided", user_skills="None")
        
        # Parse skills
        user_skills = [s.strip() for s in skills_str.split(',') if s.strip()]
        if not user_skills:
            return render_template('jobs.html', error="No skills provided", user_skills="None")
        
        logger.info(f"Searching jobs for skills: {user_skills}")
        
        # Get location (you can add location detection or ask user)
        location = "India"  # Default location, you can make this dynamic
        
        # Search for jobs using multiple job search APIs/websites
        jobs = search_jobs_online(user_skills, location)
        
        logger.info(f"Found {len(jobs)} jobs")
        
        return render_template(
            'jobs.html',
            jobs=jobs,
            user_skills=', '.join(user_skills[:5]),  # Show first 5 skills
            location=location
        )
    
    except Exception as e:
        logger.error(f"Job search error: {str(e)}")
        return render_template('jobs.html', error=f"Error searching for jobs: {str(e)}", user_skills=skills_str)


def search_jobs_online(skills, location="India"):
    """
    Search for jobs online using web scraping and APIs
    This is a simplified version - you can enhance with real APIs
    """
    jobs = []
    
    try:
        # Method 1: Search using Google Jobs (via search results)
        # Build search query
        top_skills = skills[:3]  # Use top 3 skills
        search_query = f"{' '.join(top_skills)} developer jobs in {location}"
        
        # Simulate job search results (In production, use real APIs like:
        # - LinkedIn Jobs API
        # - Indeed API  
        # - Glassdoor API
        # - Naukri API (for India)
        # - Monster API
        # Or scrape Google Jobs, LinkedIn, Indeed, etc.
        
        # For now, create sample jobs based on skills
        jobs = generate_sample_jobs(skills, location)
        
        # You can also use web scraping here
        # jobs = scrape_job_sites(search_query, location)
        
    except Exception as e:
        logger.error(f"Error in job search: {str(e)}")
    
    return jobs


def generate_sample_jobs(skills, location):
    """
    Generate relevant job recommendations based on skills
    In production, replace with real API calls
    """
    jobs = []
    
    # Job templates based on skill categories
    job_templates = {
        'python': [
            {
                'title': 'Python Developer',
                'company': 'Tech Solutions Inc.',
                'location': location,
                'type': 'Full-time',
                'description': 'Looking for experienced Python developer to build scalable applications. Experience with Django/Flask required.',
                'url': 'https://www.naukri.com/python-jobs',
                'skills_match': ['python', 'django', 'flask'],
                'posted_date': '2 days ago'
            },
            {
                'title': 'Backend Engineer - Python',
                'company': 'Startup XYZ',
                'location': location,
                'type': 'Full-time',
                'description': 'Join our team to develop REST APIs and microservices using Python. AWS experience is a plus.',
                'url': 'https://www.linkedin.com/jobs',
                'skills_match': ['python', 'rest api', 'aws'],
                'posted_date': '1 week ago'
            }
        ],
        'javascript': [
            {
                'title': 'Full Stack JavaScript Developer',
                'company': 'Digital Agency',
                'location': location,
                'type': 'Full-time',
                'description': 'Seeking Full Stack developer with React and Node.js experience. Work on exciting client projects.',
                'url': 'https://www.naukri.com/javascript-jobs',
                'skills_match': ['javascript', 'react', 'node.js'],
                'posted_date': '3 days ago'
            }
        ],
        'react': [
            {
                'title': 'React.js Frontend Developer',
                'company': 'E-commerce Leader',
                'location': location,
                'type': 'Remote',
                'description': 'Build responsive web applications using React, Redux, and modern JavaScript. 2+ years experience required.',
                'url': 'https://www.linkedin.com/jobs',
                'skills_match': ['react', 'javascript', 'redux'],
                'posted_date': '5 days ago'
            }
        ],
        'java': [
            {
                'title': 'Java Software Engineer',
                'company': 'Enterprise Corp',
                'location': location,
                'type': 'Full-time',
                'description': 'Develop enterprise applications using Java and Spring Boot. Experience with microservices architecture preferred.',
                'url': 'https://www.naukri.com/java-jobs',
                'skills_match': ['java', 'spring boot', 'microservices'],
                'posted_date': '1 day ago'
            }
        ],
        'data': [
            {
                'title': 'Data Scientist',
                'company': 'Analytics Firm',
                'location': location,
                'type': 'Full-time',
                'description': 'Analyze large datasets using Python, SQL, and machine learning. Experience with TensorFlow/PyTorch required.',
                'url': 'https://www.linkedin.com/jobs',
                'skills_match': ['python', 'sql', 'tensorflow', 'machine learning'],
                'posted_date': '4 days ago'
            }
        ],
        'aws': [
            {
                'title': 'Cloud/DevOps Engineer',
                'company': 'Cloud Services Inc.',
                'location': location,
                'type': 'Full-time',
                'description': 'Manage AWS infrastructure, implement CI/CD pipelines. Docker and Kubernetes experience essential.',
                'url': 'https://www.naukri.com/aws-jobs',
                'skills_match': ['aws', 'docker', 'kubernetes', 'ci/cd'],
                'posted_date': '1 week ago'
            }
        ]
    }
    
    # Match jobs based on user's skills
    skills_lower = [s.lower() for s in skills]
    
    for skill in skills_lower:
        # Check for skill matches in templates
        if 'python' in skill or 'py' in skill:
            jobs.extend(job_templates.get('python', []))
        if 'javascript' in skill or 'js' in skill:
            jobs.extend(job_templates.get('javascript', []))
        if 'react' in skill:
            jobs.extend(job_templates.get('react', []))
        if 'java' in skill and 'javascript' not in skill:
            jobs.extend(job_templates.get('java', []))
        if any(x in skill for x in ['pandas', 'numpy', 'tensorflow', 'pytorch', 'data']):
            jobs.extend(job_templates.get('data', []))
        if 'aws' in skill or 'docker' in skill or 'kubernetes' in skill:
            jobs.extend(job_templates.get('aws', []))
    
    # Remove duplicates
    unique_jobs = []
    seen_titles = set()
    for job in jobs:
        if job['title'] not in seen_titles:
            unique_jobs.append(job)
            seen_titles.add(job['title'])
    
    # If no jobs found, add general software engineering jobs
    if not unique_jobs:
        unique_jobs = [
            {
                'title': 'Software Engineer',
                'company': 'Various Companies',
                'location': location,
                'type': 'Full-time',
                'description': 'Multiple openings for software engineers with your skill set. Check job portals for opportunities.',
                'url': 'https://www.naukri.com',
                'skills_match': skills[:5],
                'posted_date': 'Recent'
            }
        ]
    
    return unique_jobs[:10]  # Return top 10 jobs


if __name__ == "__main__":
    app.run(debug=True)